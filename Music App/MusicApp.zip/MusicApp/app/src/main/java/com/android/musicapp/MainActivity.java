package com.android.musicapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

// This is the MainActivity class which is created automatically when you created your project
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;  // declare recyclerview
    TextView noSongsFound;     // declare textview
    ArrayList<AudioModal> songsList = new ArrayList<>();  // initialize arraylist of AudioModal which will store list of songs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get recyclerview and noSongFound textview by its id.
        recyclerView = findViewById(R.id.recycler_view);
        noSongsFound = findViewById(R.id.no_songs_found);

        if (!checkPermission()) {  // if the checkPermission is false
            requestPermission();   // then request for permission
            return;
        }
        String[] projection = {   // songs' title, path, and duration - projection stores data which we need from music file.
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC +"!=0";  // for getting only music from database
        // music files will be stored in cursor.
        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,selection,null,null);
        while(cursor.moveToNext()){
            AudioModal songsData = new AudioModal(cursor.getString(1),cursor.getString(0),cursor.getString(2));
            if(new File(songsData.getPath()).exists()){  // if songs exists then add to songsList
                songsList.add(songsData);    // adding songsData to songsList
            }
        }
        if(songsList.size()==0){  // if there is no songs then show the textview noSongsFound.
            noSongsFound.setVisibility(View.VISIBLE);   // setVisibility is used for setting the visibility of view.
        }
        else{  // recyclerview - show songs
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(new MusicListAdapter(songsList,getApplicationContext()));
        }
    }
    // checkPermission method is used for checking the permission for reading external storage files.
    boolean checkPermission(){
        int result = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if(result == PackageManager.PERMISSION_GRANTED){  // if permission is granted then return true.
            return true;
        }
        else{
            return false;  // if permission is not granted return false.
        }
    }
    // This method is for requesting the user to allow for reading external storage.
    void requestPermission(){
        if(ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE)){
            Toast.makeText(this, "READ PERMISSION IS REQUIRED, PLEASE ALLOW FROM SETTINGS", Toast.LENGTH_SHORT).show();
        }
        else{
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},123);
        }
    }

    @Override
    protected void onResume() {  // after changing color of played music title in musicAdapter class, we need to implement onResume method.
        super.onResume();
        if(recyclerView!=null){
            recyclerView.setAdapter(new MusicListAdapter(songsList,getApplicationContext()));
        }
    }
}