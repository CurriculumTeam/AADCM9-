package com.android.musicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
public class MusicPlayerActivity extends AppCompatActivity {
    TextView songTitle,currentTime,totalTime;   // declare all text views
    SeekBar seekBar;  // declare seekbar
    ImageView musicLogo,previousButton, pauseButton, nextButton;  // declare all image views which we have used in layout
    ArrayList<AudioModal> songsList;  // declare arraylist of AudioModal data type
    AudioModal currentSong;   // declare current song of AudioModal type
    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();  // get the instance of MyMediaPlayer
    int rotation = 0;  // initialize rotation for rotating music logo
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);
        // bind all views with it's id using findViewById()
        songTitle = findViewById(R.id.song_title);
        currentTime = findViewById(R.id.current_time);
        totalTime = findViewById(R.id.total_time);
        seekBar = findViewById(R.id.seek_bar);
        musicLogo = findViewById(R.id.music_logo);
        previousButton = findViewById(R.id.previous);
        pauseButton = findViewById(R.id.pause);
        nextButton = findViewById(R.id.next);
        songTitle.setSelected(true);  // for marquee in text view

        // get the list of songs from MusicListAdapter where we pass "LIST" using putExtra()
        songsList = (ArrayList<AudioModal>) getIntent().getSerializableExtra("LIST");
        setResourcesWithMusic();  // call setResourcesWithMusic method
        // implementing runOnUniThread for seekbar progress, current time
        MusicPlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer!=null){
                    seekBar.setProgress(mediaPlayer.getCurrentPosition());  // seekbar will move forward
                    currentTime.setText(convertToMMSS(mediaPlayer.getCurrentPosition()+""));

                    if(mediaPlayer.isPlaying()){                 // if music is playing then
                        pauseButton.setImageResource(R.drawable.ic_baseline_pause_circle_outline_24);  // change to pause icn
                        musicLogo.setRotation(rotation++);  // set rotation to music logo

                    }
                    else{                                 // if music is not playing then
                        pauseButton.setImageResource(R.drawable.ic_baseline_play_circle_outline_24); // change to play icon
                        musicLogo.setRotation(0);   // stop rotation when music is paused
                    }
                }
                new Handler().postDelayed(this,10);  // in each 10 millisecond it will check the media player and update seekbar and current time
            }
        });
        // when user is changing progress of seekBar.
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaPlayer!=null && fromUser){  // if mediaPlayer is not null and the request is from user then
                    mediaPlayer.seekTo(progress);   // seek the mediaPlayer to that progress.
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
    // for setting all the resources like title, duration and on clicks on icons.
    void setResourcesWithMusic(){
        currentSong = songsList.get(MyMediaPlayer.currentIndex);  // get the current song
        songTitle.setText(currentSong.getTitle());                // set title of current song
        totalTime.setText(convertToMMSS(currentSong.getDuration()));  // set duration of current song
        pauseButton.setOnClickListener(view -> pauseSong());         // set onClickListener in pause button so that if we click it, music stops
        nextButton.setOnClickListener(view -> playNextSong());      // set onClickListener in next button so that if you click it, next song will be played
        previousButton.setOnClickListener(view -> playPreviousSong()); // set onClickListener in previous button so that if you click it, previous song will be played
        playMusic();  // call playMusic() method to play music.
    }
    // method to play music
    private void playMusic(){
        mediaPlayer.reset(); // reset mediaPlayer
        try {  // use try-catch block to handle exception
            mediaPlayer.setDataSource(currentSong.getPath());   // set data source of current song
            mediaPlayer.prepare();  // prepare media player
            mediaPlayer.start();   // start media player
            seekBar.setProgress(0);  // set progress to the seekBar, initially will be 0.
            seekBar.setMax(mediaPlayer.getDuration()); // maximum position of seekBar will be the duration of song
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    // method to play next song
    private void playNextSong(){
        if(MyMediaPlayer.currentIndex == songsList.size()-1){  // check if current song is the last song of list, if so return
            return;
        }
        MyMediaPlayer.currentIndex += 1;   // if current song is not last song then increase index by 1.
        mediaPlayer.reset();               // reset the mediaPlayer
        setResourcesWithMusic();           // call setResourceWithMusic method to set all resources of next song.
    }
    // method to play previous song
    private void playPreviousSong(){
        if(MyMediaPlayer.currentIndex == 0){   // if the current song is the first song os the list then we cannot go previous so return
            return;
        }
        MyMediaPlayer.currentIndex -= 1;  // decrease the current index by 1 so that previous song will play
        mediaPlayer.reset();              // reset the media player
        setResourcesWithMusic();          // call setResourceWithMusic method
    }
    // method to pause song
    private void pauseSong(){
        if(mediaPlayer.isPlaying()){      // if the song is playing pause it
            mediaPlayer.pause();
        }
        else{
            mediaPlayer.start();     // if not playing then start it.
        }
    }
    // this is the method to convert duration of song into milliSecond string format.
    public static String convertToMMSS(String duration){
        Long millis = Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis) % TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(millis) % TimeUnit.MINUTES.toSeconds(1));

    }
}