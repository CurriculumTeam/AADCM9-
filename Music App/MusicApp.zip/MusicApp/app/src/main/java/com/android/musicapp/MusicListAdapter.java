package com.android.musicapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
// Adapter class for recycler view
public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.ViewHolder> {
    ArrayList<AudioModal> songsList;  // declare array list of AudioModal for storing list of songs
    Context context;  // declare context

    public MusicListAdapter(ArrayList<AudioModal> songsList, Context context) {   // constructor created
        this.songsList = songsList;
        this.context = context;
    }

    @NonNull
    @Override // This method will helps to create view and return view.
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_items,parent,false);
        return new MusicListAdapter.ViewHolder(view);
    }

    @Override  // will bind all the data of list to the views.
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AudioModal songsData = songsList.get(position);  // getting single data form list
        holder.musicTitle.setText(songsData.getTitle());  // setting title of song to the musicTitle view.
        // It will change the colour of music title if the song is playing
        if(MyMediaPlayer.currentIndex == position){
            holder.musicTitle.setTextColor(Color.parseColor("#FF0000"));   // if playing set colour to red
        }
        else{
            holder.musicTitle.setTextColor(Color.parseColor("#000000"));  // if not playing set colour to black
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //navigate to another activity
                MyMediaPlayer.getInstance().reset();   // will reset the media player
                MyMediaPlayer.currentIndex = holder.getAdapterPosition();  // will add currentIndex to that position
                Intent intent = new Intent(context,MusicPlayerActivity.class);  // when you clicked on music will take you to music player activity
                intent.putExtra("LIST",songsList);  // will pass the songsList into music player activity
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);  // start the activity
            }
        });
    }

    @Override  // will return total count of data.
    public int getItemCount() {
        return songsList.size();
    }

    public static class  ViewHolder extends RecyclerView.ViewHolder{
        TextView musicTitle;   // declare TextView
        ImageView musicIcon;  // declare ImageView
        public ViewHolder(@NonNull View itemView) {
            super(itemView); // get this view by it's id
            musicTitle = itemView.findViewById(R.id.music_title);
            musicIcon = itemView.findViewById(R.id.music_icon);
        }
    }
}
