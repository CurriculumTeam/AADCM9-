package com.android.musicapp;

import android.media.MediaPlayer;
// this, MyMediaPlayer class can be accessed from anywhere with class name.
public class MyMediaPlayer {
    static MediaPlayer instance;  // we need media player to play music so instance of MediaPlayer is created.
    public static MediaPlayer getInstance(){
        if(instance == null){   // if there is no instance then we will create one
            instance = new MediaPlayer();
        }
        return instance;  // if there is instance then will return it.
    }
    // song is not clicked yet
    public static int currentIndex = -1;

}
