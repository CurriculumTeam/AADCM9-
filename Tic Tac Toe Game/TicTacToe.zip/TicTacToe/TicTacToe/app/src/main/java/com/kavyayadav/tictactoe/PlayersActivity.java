package com.kavyayadav.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.kavyayadav.tictactoe.databinding.ActivityPlayersBinding;

import java.util.Objects;
public class PlayersActivity extends AppCompatActivity {
    ActivityPlayersBinding binding;  // declare ActivityPlayersBinding

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlayersBinding.inflate(getLayoutInflater()); // call inflate, it creates an instance of binding class for activity use
        setContentView(binding.getRoot()); // get root and pass it to make it the active view on the screen

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);  // portrait restrict
        // lambda expression
        binding.btnLetsPlay.setOnClickListener(view -> {   // adding on click on button to move to another activity.
            String playerOne = Objects.requireNonNull(binding.etPlayerOne.getText()).toString(); // get name of player 1
            String playerTwo = Objects.requireNonNull(binding.etPlayerTwo.getText()).toString(); // get name of player 2

            if (TextUtils.isEmpty(playerOne)) {   // if the player one name is not given then
                binding.etPlayerOne.setError("Please Enter Player One Name");  // show them error and message
            } else if (TextUtils.isEmpty(playerTwo)) {  // if the player two name is not given then
                binding.etPlayerTwo.setError("Please Enter Player Two Name");  // show them error and message
            } else if(playerOne.equals(playerTwo)){  // if the name of both players are same then show them message as a Toast.
                Toast.makeText(this, "Please Enter Different Players Name", Toast.LENGTH_SHORT).show();
            }
            else {  // if all above conditions are okay then go to next activity i.e GameActivity
                Intent intent = new Intent(PlayersActivity.this, GameActivity.class);
                intent.putExtra("PlayerOne", playerOne);  // taking name of player one in GameActivity
                intent.putExtra("PlayerTwo", playerTwo);  // taking name of player two in GameActivity
                startActivity(intent); // start the activity.
                binding.etPlayerOne.setText("");  // after getting name of player one set the text empty
                binding.etPlayerTwo.setText("");  // after getting name of player two set the text empty
            }
        });
    }
}