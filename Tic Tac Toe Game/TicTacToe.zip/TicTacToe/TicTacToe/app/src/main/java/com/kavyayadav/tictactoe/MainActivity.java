package com.kavyayadav.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

import com.kavyayadav.tictactoe.databinding.ActivityMainBinding;
//This MainActivity class is created automatically when you created your project.
public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;   // declaring ActivityMainBinding
    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());  // call inflate it creates an instance of binding class for activity use.
        setContentView(binding.getRoot()); // get root and pass it to make it the active view on the screen

        // portrait restrict
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // lambda expression
        binding.btnGetStarted.setOnClickListener(view -> {    // adding on click on button to move to another activity.
            startActivity(new Intent(MainActivity.this, PlayersActivity.class));  // form MainActivity to PlayersActivity.
            finish();  // finish is used so that app will close when we come back.
        });
    }
}