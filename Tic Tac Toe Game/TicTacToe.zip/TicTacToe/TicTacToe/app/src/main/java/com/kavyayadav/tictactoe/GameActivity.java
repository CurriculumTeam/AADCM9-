package com.kavyayadav.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textview.MaterialTextView;
import com.kavyayadav.tictactoe.databinding.ActivityGameBinding;

import java.util.ArrayList;
import java.util.List;
public class GameActivity extends AppCompatActivity {
    List<int[]> winPositions = new ArrayList<>();  // create List of array type which will store the win positions.
    int[] boxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0};  // create array of integer for boxPositions
    int playerChance = 1;  // initialize a variable called playerChance which will helps to track player chance.
    int boxesSelected = 1; // initialize a variable called boxesSelected which will helps to track selected boxes.

    ActivityGameBinding binding;  // declare ActivityGameBinding for GameActivity.

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGameBinding.inflate(getLayoutInflater()); // call inflate, it creates an instance of binding class for activity use.
        setContentView(binding.getRoot()); // get root and pass it to make the active view on the screen
        // portrait restrict
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // add all the winning positions to list of winPositions.
        winPositions.add(new int[]{0, 1, 2});
        winPositions.add(new int[]{3, 4, 5});
        winPositions.add(new int[]{6, 7, 8});
        winPositions.add(new int[]{0, 3, 6});
        winPositions.add(new int[]{1, 4, 7});
        winPositions.add(new int[]{2, 5, 8});
        winPositions.add(new int[]{2, 4, 6});
        winPositions.add(new int[]{0, 4, 8});

        // get player name from player activity
        String getPlayerOneName = getIntent().getStringExtra("PlayerOne");
        String getPlayerTwoName = getIntent().getStringExtra("PlayerTwo");

        binding.playerOneName.setText(getPlayerOneName);  // display name of player one
        binding.playerTwoName.setText(getPlayerTwoName);  // display name of player two

        binding.btnRestartGame.setOnClickListener(view -> { // to restart the game.
           restartGame();
        });
        // add setOnClickListener to each boxes
        binding.box1.setOnClickListener(view -> {
            if (isBoxSelected(0)) {    // if selected box is of 0th position
                performAction((ShapeableImageView) view, 0);  // then call performAction method.
            }
        });

        binding.box2.setOnClickListener(view -> {
            if (isBoxSelected(1)) {   // if selected box is of 1st position
                performAction((ShapeableImageView) view, 1);  // then call performAction method.
            }
        });

        binding.box3.setOnClickListener(view -> {
            if (isBoxSelected(2)) {  // if selected box is of 2nd position
                performAction((ShapeableImageView) view, 2);  // then call performAction method.
            }
        });

        binding.box4.setOnClickListener(view -> {
            if (isBoxSelected(3)) {   // if selected box is of 3rd position
                performAction((ShapeableImageView) view, 3);  // then call performAction method.
            }
        });

        binding.box5.setOnClickListener(view -> {
            if (isBoxSelected(4)) {    // if selected box is of 4th position
                performAction((ShapeableImageView) view, 4);  // then call performAction method.
            }
        });

        binding.box6.setOnClickListener(view -> {
            if (isBoxSelected(5)) {    // if selected box is of 5th position
                performAction((ShapeableImageView) view, 5); // then call performAction method.
            }
        });

        binding.box7.setOnClickListener(view -> {
            if (isBoxSelected(6)) {    // if selected box is of 6th position
                performAction((ShapeableImageView) view, 6); // then call performAction method.
            }
        });

        binding.box8.setOnClickListener(view -> {
            if (isBoxSelected(7)) {    // if selected box is of 7th position
                performAction((ShapeableImageView) view, 7); // then call performAction method.
            }
        });

        binding.box9.setOnClickListener(view -> {
            if (isBoxSelected(8)) {    // if selected box is of 8th position
                performAction((ShapeableImageView) view, 8); // then call performAction method.
            }
        });
    }
    // this method will perform given action when box of certain position is clicked.
    private void performAction(ShapeableImageView selectedBox, int selectedBoxPosition) {
        boxPositions[selectedBoxPosition] = playerChance;  //
        if (playerChance == 1) {  // if playerChance is 1 then set icon of player one in the clicked box using setImageResource().
            selectedBox.setImageResource(R.drawable.ic_player_one);
            if (isPlayerWin()) {  // if the player wins then show dialog box with player name and message.
                resultsDialog(binding.playerOneName.getText().toString() + " has won the Game " + getEmojiByUnicode(0x1f60A)); // getEmojiByUnicode will add emoji
            } else if (boxesSelected == 9) {   // if the selected box is 9 and all other conditions given above are false then match is draw.
                resultsDialog("It's a draw " + getEmojiByUnicode(0x1F61D));  // show result as dialog box.
            } else {   // if all above conditions are false then change the player chance.
                changePlayerChance(2);  // changedPlayerChance method is called.
                boxesSelected++;  // increase the boxesSelected variable by 1.
            }
        } else {  // if it is not player 1
            selectedBox.setImageResource(R.drawable.ic_player_two);  // set player 2 icon
            if (isPlayerWin()) {   //if the player wins then show dialog box with player name and message.
                resultsDialog(binding.playerTwoName.getText().toString() + " has won the Game "+ getEmojiByUnicode(0x1f60A));
            } else if (boxesSelected == 9) {  // if the selected box is 9 and all other conditions given above are false then match is draw.
                resultsDialog(" It's a draw " +  getEmojiByUnicode(0x1F61D));
            } else {   // if all above conditions are false then change the player chance.
                changePlayerChance(1);  // changedPlayerChance method is called.
                boxesSelected++;  // increase the boxesSelected variable by 1.
            }
        }
    }
    // This method will change the player name background according to turn.
    private void changePlayerChance(int currentPlayerChance) {
        playerChance = currentPlayerChance;
        if (playerChance == 1) {  // if it is player 1 then
            binding.playerOneName.setTextColor(getColor(R.color.neon));  // set player one name text color
            binding.playerTwoName.setTextColor(getColor(R.color.white)); // set player two name color to white
            binding.playerOneLinearLayout.setBackgroundColor(getColor(R.color.yellow)); // change player one filed to yellow color which will indicate that it's player one turns.
            binding.playerTwoLinearLayout.setBackgroundColor(getColor(R.color.neon));  // change player two filed to neon color
        } else {  // if it not player 1 then do same thing for player 2.
            binding.playerTwoName.setTextColor(getColor(R.color.neon));
            binding.playerOneName.setTextColor(getColor(R.color.white));
            binding.playerTwoLinearLayout.setBackgroundColor(getColor(R.color.yellow));
            binding.playerOneLinearLayout.setBackgroundColor(getColor(R.color.neon));
        }
    }
    // this method will return true if the player is winner.
    private boolean isPlayerWin() {
        boolean result = false;    // initially store false in result

        for (int i = 0; i < winPositions.size(); i++) {  // using loop check condition
            int[] combination = winPositions.get(i);
            if (boxPositions[combination[0]] == playerChance && boxPositions[combination[1]] == playerChance && boxPositions[combination[2]] == playerChance) {
                result = true;  // if the above condition is true then change result value to true.
            }
        }
        return result;  // return result
    }
    // this method will return true if box is selected.
    private boolean isBoxSelected(int position) {
        return boxPositions[position] == 0;
    }
    // method to reset the game, change everything as previous.
    public void restartGame() {
        boxPositions = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
        playerChance = 1;
        boxesSelected = 1;

        binding.playerOneName.setTextColor(getColor(R.color.neon));
        binding.playerTwoName.setTextColor(getColor(R.color.white));

        binding.playerOneLinearLayout.setBackgroundColor(getColor(R.color.yellow));
        binding.playerTwoLinearLayout.setBackgroundColor(getColor(R.color.neon));

        binding.box1.setImageResource(R.drawable.square_background);
        binding.box2.setImageResource(R.drawable.square_background);
        binding.box3.setImageResource(R.drawable.square_background);
        binding.box4.setImageResource(R.drawable.square_background);
        binding.box5.setImageResource(R.drawable.square_background);
        binding.box6.setImageResource(R.drawable.square_background);
        binding.box7.setImageResource(R.drawable.square_background);
        binding.box8.setImageResource(R.drawable.square_background);
        binding.box9.setImageResource(R.drawable.square_background);
    }
    // this method will create dialog for result
    void resultsDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  // AlertDialog is created.
        builder.setTitle("Game Result");   // will set the title of AlertDialog
        builder.setCancelable(false);    // set the setCancelable to false
        builder.setMessage(message);   // will set message
        builder.setPositiveButton("Play Again", (dialogInterface, i) -> restartGame()); // for replay the game
        builder.setNegativeButton("Exit", (dialogInterface, i) -> finish());   // to exit from game
        AlertDialog dialog = builder.create();
        dialog.show();   // will show the dialog
    }
    // for getting emojis.
    public String getEmojiByUnicode(int unicode){
        return new String(Character.toChars(unicode));
    }
}